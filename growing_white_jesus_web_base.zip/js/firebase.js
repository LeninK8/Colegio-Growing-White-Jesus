// Aquí irá la configuración de Firebase
// La llenaremos después con tus datos reales
